import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sun, Moon } from "lucide-react";
import { AuthCard } from "./components/AuthCard";
import logoImg from "../imports/Infloro_Final_Logo-removebg-preview-1.png";

type Screen =
  | "login" | "creatorLogin"
  | "agencySignup" | "creatorSignup"
  | "forgotPassword" | "emailVerification"
  | "resetPassword" | "resetSuccess";

function InfloroLogo() {
  return (
    <img
      src={logoImg}
      alt="Infloro"
      style={{ height: "72px", width: "auto" }}
    />
  );
}

function ThemeToggle({ dark, onToggle }: { dark: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      className="relative flex items-center justify-center w-10 h-10 rounded-xl transition-all duration-200 hover:scale-105 active:scale-95"
      style={{
        background: dark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.06)",
        border: `1px solid ${dark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.1)"}`,
      }}
      aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}
    >
      <AnimatePresence mode="wait">
        {dark ? (
          <motion.div key="sun"
            initial={{ rotate: -90, opacity: 0, scale: 0.7 }}
            animate={{ rotate: 0, opacity: 1, scale: 1 }}
            exit={{ rotate: 90, opacity: 0, scale: 0.7 }}
            transition={{ duration: 0.22 }}
          >
            <Sun size={17} style={{ color: "#F59E0B" }} />
          </motion.div>
        ) : (
          <motion.div key="moon"
            initial={{ rotate: 90, opacity: 0, scale: 0.7 }}
            animate={{ rotate: 0, opacity: 1, scale: 1 }}
            exit={{ rotate: -90, opacity: 0, scale: 0.7 }}
            transition={{ duration: 0.22 }}
          >
            <Moon size={17} style={{ color: "#4A7DFF" }} />
          </motion.div>
        )}
      </AnimatePresence>
    </button>
  );
}

function Background({ dark }: { dark: boolean }) {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      <div className="absolute" style={{
        top: "-15%", left: "-8%", width: "550px", height: "550px", borderRadius: "50%",
        background: `radial-gradient(circle, ${dark ? "rgba(74,125,255,0.12)" : "rgba(74,125,255,0.07)"} 0%, transparent 70%)`,
        transition: "background 0.4s",
      }} />
      <div className="absolute" style={{
        bottom: "-10%", right: "-5%", width: "480px", height: "480px", borderRadius: "50%",
        background: `radial-gradient(circle, ${dark ? "rgba(139,92,246,0.10)" : "rgba(139,92,246,0.06)"} 0%, transparent 70%)`,
        transition: "background 0.4s",
      }} />
      <div className="absolute" style={{
        top: "40%", left: "30%", width: "360px", height: "360px", borderRadius: "50%",
        background: `radial-gradient(circle, ${dark ? "rgba(255,45,120,0.06)" : "rgba(255,45,120,0.04)"} 0%, transparent 70%)`,
        transition: "background 0.4s",
      }} />
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("login");
  const [role, setRole] = useState<"agency" | "creator">("agency");
  const [dark, setDark] = useState(true);

  const handleNavigate = (s: Screen) => {
    setScreen(s);
    if (s === "agencySignup") setRole("agency");
    if (s === "creatorSignup" || s === "creatorLogin") setRole("creator");
  };

  return (
    <div className={dark ? "dark" : ""} style={{ minHeight: "100vh", width: "100%", fontFamily: "Inter, sans-serif" }}>
      <div style={{
        minHeight: "100vh",
        width: "100%",
        background: dark ? "#0B0F19" : "linear-gradient(135deg, #F8FAFC 0%, #FFFFFF 50%, #F3F4F6 100%)",
        position: "relative",
        transition: "background 0.4s ease",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}>
        <Background dark={dark} />

        {/* Theme toggle */}
        <div className="absolute top-4 right-4 z-50">
          <ThemeToggle dark={dark} onToggle={() => setDark(d => !d)} />
        </div>

        {/* Centered auth card */}
        <div className="relative z-10 w-full flex flex-col items-center px-4 py-12">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35 }}
            className="mb-8"
          >
            <InfloroLogo />
          </motion.div>

          {/* Card */}
          <div className="w-full max-w-md">
            <AnimatePresence mode="wait">
              <motion.div
                key={screen}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -14 }}
                transition={{ duration: 0.22 }}
              >
                <div
                  className="rounded-3xl p-8"
                  style={{
                    background: dark ? "rgba(18,24,38,0.88)" : "rgba(255,255,255,0.97)",
                    border: `1px solid ${dark ? "rgba(255,255,255,0.09)" : "rgba(0,0,0,0.08)"}`,
                    backdropFilter: "blur(28px)",
                    boxShadow: dark
                      ? "0 32px 80px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.04) inset"
                      : "0 12px 48px rgba(0,0,0,0.10), 0 2px 8px rgba(0,0,0,0.06), 0 0 0 1px rgba(255,255,255,0.8) inset",
                    transition: "background 0.35s, border-color 0.35s, box-shadow 0.35s",
                  }}
                >
                  <AuthCard screen={screen} onNavigate={handleNavigate} role={role} onRoleChange={setRole} />
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Bottom nav */}
            <div className="flex items-center justify-center gap-5 mt-5 flex-wrap">
              {([
                { label: "Sign In", s: "login" },
                { label: "Agency", s: "agencySignup" },
                { label: "Creator", s: "creatorSignup" },
                { label: "Forgot Password", s: "forgotPassword" },
              ] as { label: string; s: Screen }[]).map((l, i, arr) => (
                <span key={l.label} className="flex items-center gap-5">
                  <button onClick={() => handleNavigate(l.s)}
                    className="text-xs transition-colors hover:underline"
                    style={{ color: screen === l.s ? "#4A7DFF" : "var(--infloro-text-muted)" }}>
                    {l.label}
                  </button>
                  {i < arr.length - 1 && <span style={{ color: "var(--infloro-text-muted)", fontSize: "10px" }}>·</span>}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
