import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { TrendingUp, Users, CheckCircle, Clock, Star, Activity } from "lucide-react";

const GRAD = "linear-gradient(135deg, #4A7DFF, #8B5CF6, #FF2D78)";

const gradientText: React.CSSProperties = {
  background: GRAD,
  WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent",
  backgroundClip: "text",
};

const stats = [
  { label: "Creators", display: "50K+" },
  { label: "Brands", display: "10K+" },
  { label: "Collabs", display: "250K+" },
  { label: "Satisfaction", display: "95%" },
];

const activities = [
  { avatar: "S", name: "Sarah K.", action: "joined Summer Fashion Campaign", time: "2m ago", color: "#4A7DFF" },
  { avatar: "M", name: "12 creators", action: "submitted content for review", time: "8m ago", color: "#8B5CF6" },
  { avatar: "R", name: "Rahul A.", action: "sent collaboration request", time: "15m ago", color: "#FF2D78" },
  { avatar: "T", name: "Tech Program", action: "approval completed", time: "1h ago", color: "#4A7DFF" },
];

const campaigns = [
  { name: "Summer Fashion Campaign", applicants: 124, budget: "₹75,000", status: "Active" },
  { name: "Tech Creator Program", applicants: 89, budget: "₹1,20,000", status: "Reviewing" },
  { name: "Wellness Influencer Drive", applicants: 56, budget: "₹45,000", status: "Completed" },
];

const creatorCards = [
  { handle: "@fashionista", followers: "120K", icon: "📸", type: "Instagram" },
  { handle: "@techtalks", followers: "85K", icon: "▶️", type: "YouTube" },
  { handle: "@lifewithlena", followers: "45K", icon: "✨", type: "Lifestyle" },
];

function useCountUp(target: number, duration = 1400) {
  const [count, setCount] = useState(0);
  const started = useRef(false);
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    const start = Date.now();
    const tick = () => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * target));
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [target, duration]);
  return count;
}

function StatCard({ display, label, index }: { display: string; label: string; index: number }) {
  const numericPart = parseInt(display.replace(/[^0-9]/g, ""));
  const count = useCountUp(numericPart, 1200 + index * 150);
  const suffix = display.replace(/[0-9]/g, "");
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 + index * 0.1 }}
      className="flex flex-col items-center p-2.5 rounded-xl"
      style={{ background: "var(--infloro-stat-bg)", border: "1px solid var(--infloro-border)" }}
    >
      <div style={{ ...gradientText, fontSize: "17px", fontWeight: 700, lineHeight: 1.2 }}>
        {count}{suffix}
      </div>
      <div style={{ color: "var(--infloro-text-muted)", fontSize: "10px", marginTop: "2px" }}>{label}</div>
    </motion.div>
  );
}

export function PreviewPanel({ role }: { role: "agency" | "creator" }) {
  const [activeActivity, setActiveActivity] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setActiveActivity(prev => (prev + 1) % activities.length), 2800);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative flex flex-col h-full overflow-hidden select-none" style={{ fontFamily: "Inter, sans-serif" }}>
      {/* Ambient orbs */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-56 h-56 rounded-full blur-3xl" style={{ background: "var(--infloro-orb-1)" }} />
        <div className="absolute bottom-1/3 right-1/4 w-44 h-44 rounded-full blur-3xl" style={{ background: "var(--infloro-orb-2)" }} />
        <div className="absolute top-2/3 left-1/3 w-32 h-32 rounded-full blur-2xl" style={{ background: "var(--infloro-orb-3)" }} />
      </div>

      <div className="relative z-10 flex flex-col h-full p-5 gap-3.5">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span style={{ color: "var(--infloro-text-muted)", fontSize: "11px" }}>Live Dashboard</span>
          </div>
          <div style={{ color: "var(--infloro-text-primary)", fontWeight: 600, fontSize: "15px" }}>Campaign Performance</div>
        </motion.div>

        {/* KPI metrics */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="grid grid-cols-2 gap-2">
          {[
            { icon: Activity, label: "Active Campaigns", value: "24", color: "#4A7DFF" },
            { icon: Clock, label: "Pending Approvals", value: "12", color: "#F59E0B" },
            { icon: Users, label: "Applications", value: "148", color: "#8B5CF6" },
            { icon: TrendingUp, label: "Revenue Tracked", value: "₹12.4L", color: "#22c55e" },
          ].map((m, i) => (
            <motion.div key={m.label}
              initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.25 + i * 0.05 }}
              className="p-2.5 rounded-xl flex items-center gap-2"
              style={{ background: "var(--infloro-surface)", border: "1px solid var(--infloro-border)" }}
            >
              <div className="p-1.5 rounded-lg" style={{ background: `${m.color}20` }}>
                <m.icon size={13} style={{ color: m.color }} />
              </div>
              <div>
                <div style={{ color: "var(--infloro-text-primary)", fontSize: "13px", fontWeight: 600 }}>{m.value}</div>
                <div style={{ color: "var(--infloro-text-muted)", fontSize: "9px", lineHeight: 1.3 }}>{m.label}</div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Campaign cards */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.38 }}>
          <div style={{ color: "var(--infloro-text-muted)", fontSize: "11px", fontWeight: 500, marginBottom: "6px" }}>Active Campaigns</div>
          <div className="flex flex-col gap-1.5">
            {campaigns.map((c, i) => (
              <motion.div key={c.name}
                initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.42 + i * 0.06 }}
                className="px-3 py-2 rounded-xl flex items-center justify-between"
                style={{ background: "var(--infloro-surface)", border: "1px solid var(--infloro-border)" }}
              >
                <div>
                  <div style={{ color: "var(--infloro-text-primary)", fontSize: "11px", fontWeight: 500 }}>{c.name}</div>
                  <div style={{ color: "var(--infloro-text-muted)", fontSize: "10px", marginTop: "1px" }}>{c.applicants} applicants · {c.budget}</div>
                </div>
                <span className="text-xs px-2 py-0.5 rounded-full font-medium"
                  style={{
                    background: `var(--infloro-badge-bg-${c.status.toLowerCase()})`,
                    color: `var(--infloro-badge-text-${c.status.toLowerCase()})`,
                    fontSize: "10px",
                  }}
                >{c.status}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Activity feed */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.55 }}>
          <div style={{ color: "var(--infloro-text-muted)", fontSize: "11px", fontWeight: 500, marginBottom: "6px" }}>Creator Activity</div>
          <div className="flex flex-col gap-1">
            {activities.map((a, i) => (
              <motion.div key={`${a.name}-${i}`}
                animate={{ opacity: i === activeActivity ? 1 : 0.45 }}
                transition={{ duration: 0.4 }}
                className="flex items-center gap-2 px-2 py-1.5 rounded-lg"
                style={{ background: i === activeActivity ? "var(--infloro-activity-active)" : "transparent" }}
              >
                <div className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                  style={{ background: `linear-gradient(135deg, ${a.color}, #8B5CF6)`, fontSize: "9px" }}>
                  {a.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <span style={{ color: "var(--infloro-text-primary)", fontSize: "11px", fontWeight: 500 }}>{a.name} </span>
                  <span style={{ color: "var(--infloro-text-secondary)", fontSize: "11px" }}>{a.action}</span>
                </div>
                <span style={{ color: "var(--infloro-text-muted)", fontSize: "10px", flexShrink: 0 }}>{a.time}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Stats counters */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}>
          <div style={{ color: "var(--infloro-text-muted)", fontSize: "11px", fontWeight: 500, marginBottom: "6px" }}>Platform Stats</div>
          <div className="grid grid-cols-4 gap-1.5">
            {stats.map((s, i) => <StatCard key={s.label} display={s.display} label={s.label} index={i} />)}
          </div>
        </motion.div>

        {/* Social proof */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.85 }}
          className="flex items-center justify-between px-3 py-2 rounded-xl"
          style={{ background: "var(--infloro-surface)", border: "1px solid var(--infloro-border)" }}>
          <div className="flex -space-x-1.5">
            {["#4A7DFF", "#8B5CF6", "#FF2D78", "#22c55e", "#F59E0B"].map((c, i) => (
              <div key={i} className="w-5 h-5 rounded-full flex items-center justify-center text-white font-bold"
                style={{ background: c, fontSize: "8px", border: "1.5px solid var(--infloro-page-bg)" }}>
                {["A", "C", "R", "M", "P"][i]}
              </div>
            ))}
          </div>
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map(s => <Star key={s} size={9} fill="#F59E0B" style={{ color: "#F59E0B" }} />)}
            <span style={{ color: "var(--infloro-text-primary)", fontSize: "11px", fontWeight: 600, marginLeft: "2px" }}>4.9/5</span>
          </div>
          <div className="flex items-center gap-1">
            <CheckCircle size={11} style={{ color: "#22c55e" }} />
            <span style={{ color: "var(--infloro-text-secondary)", fontSize: "10px" }}>Trusted worldwide</span>
          </div>
        </motion.div>

        {/* Floating creator cards */}
        <div className="flex gap-2">
          {creatorCards.map((c, i) => (
            <motion.div key={c.handle}
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 2.8, delay: i * 0.6, repeat: Infinity, ease: "easeInOut" }}
              className="flex-1 p-2.5 rounded-xl"
              style={{ background: "var(--infloro-surface)", border: "1px solid var(--infloro-border)" }}
            >
              <div style={{ fontSize: "16px", lineHeight: 1 }}>{c.icon}</div>
              <div style={{ color: "var(--infloro-text-primary)", fontSize: "12px", fontWeight: 600, marginTop: "4px" }}>{c.followers}</div>
              <div style={{ color: "var(--infloro-text-muted)", fontSize: "9px", marginTop: "1px" }}>{c.handle}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
