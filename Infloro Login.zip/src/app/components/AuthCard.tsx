import { useState, useRef, type ReactNode } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Eye, EyeOff, Mail, Lock, User, Phone, Building2, Globe,
  Instagram, Youtube,
  ArrowRight, ArrowLeft, CheckCircle, Shield, RefreshCw,
} from "lucide-react";

function GoogleIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}

function LinkedInIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="#0A66C2">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
    </svg>
  );
}

type Screen =
  | "login" | "creatorLogin"
  | "agencySignup" | "creatorSignup"
  | "forgotPassword" | "emailVerification"
  | "resetPassword" | "resetSuccess";

const GRAD = "linear-gradient(135deg, #4A7DFF, #8B5CF6, #FF2D78)";

const gradientText: React.CSSProperties = {
  background: GRAD,
  WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent",
  backgroundClip: "text",
};

// ─── Primitives ────────────────────────────────────────────────────────────────

function FloatingInput({
  label, type = "text", icon: Icon, value, onChange, autoComplete,
}: {
  label: string; type?: string; icon?: any; value: string;
  onChange: (v: string) => void; autoComplete?: string;
}) {
  const [focused, setFocused] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const isPassword = type === "password";
  const lifted = focused || value.length > 0;

  return (
    <div className="relative">
      <div
        className="relative rounded-xl overflow-hidden transition-all duration-200"
        style={{
          background: "var(--infloro-input-bg)",
          border: `1px solid ${focused ? "#4A7DFF" : "var(--infloro-input-border)"}`,
          boxShadow: focused ? "0 0 0 3px rgba(74,125,255,0.15)" : "none",
        }}
      >
        {Icon && (
          <div className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none transition-colors duration-200">
            <Icon size={15} style={{ color: focused ? "#4A7DFF" : "var(--infloro-text-muted)" }} />
          </div>
        )}
        <label
          className="absolute transition-all duration-200 pointer-events-none"
          style={{
            left: Icon ? "40px" : "12px",
            top: lifted ? "7px" : "50%",
            transform: lifted ? "none" : "translateY(-50%)",
            fontSize: lifted ? "10px" : "13px",
            color: focused ? "#4A7DFF" : "var(--infloro-text-muted)",
            fontWeight: 500,
          }}
        >
          {label}
        </label>
        <input
          type={isPassword && showPass ? "text" : type}
          value={value}
          autoComplete={autoComplete}
          onChange={e => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          className="w-full pt-5 pb-2 bg-transparent outline-none text-sm"
          style={{
            paddingLeft: Icon ? "40px" : "12px",
            paddingRight: isPassword ? "40px" : "12px",
            color: "var(--infloro-text-primary)",
          }}
        />
        {isPassword && (
          <button type="button" onClick={() => setShowPass(!showPass)}
            className="absolute right-3 top-1/2 -translate-y-1/2 transition-colors"
            style={{ color: "var(--infloro-text-muted)" }}
          >
            {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
          </button>
        )}
      </div>
    </div>
  );
}

function GradientButton({ children, onClick, type = "button", loading = false }: {
  children: ReactNode; onClick?: () => void; type?: "button" | "submit"; loading?: boolean;
}) {
  return (
    <button type={type} onClick={onClick}
      className="w-full py-3 rounded-xl text-sm font-semibold text-white transition-all duration-200 hover:scale-[1.02] hover:shadow-lg active:scale-[0.98] flex items-center justify-center gap-2"
      style={{ background: GRAD, boxShadow: "0 4px 20px rgba(74,125,255,0.28)" }}
    >
      {loading ? <RefreshCw size={15} className="animate-spin" /> : children}
    </button>
  );
}

function SocialButtons() {
  return (
    <div className="flex flex-col gap-2">
      <button
        className="w-full py-2.5 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all hover:scale-[1.01]"
        style={{
          background: "var(--infloro-surface)",
          border: "1px solid var(--infloro-border)",
          color: "var(--infloro-text-primary)",
        }}
      >
        <GoogleIcon /> Continue with Google
      </button>
      <button
        className="w-full py-2.5 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all hover:scale-[1.01]"
        style={{
          background: "var(--infloro-surface)",
          border: "1px solid var(--infloro-border)",
          color: "var(--infloro-text-secondary)",
        }}
      >
        <LinkedInIcon /> Continue with LinkedIn
      </button>
    </div>
  );
}

function Divider() {
  return (
    <div className="flex items-center gap-3">
      <div className="flex-1 h-px" style={{ background: "var(--infloro-divider)" }} />
      <span className="text-xs" style={{ color: "var(--infloro-text-muted)" }}>or</span>
      <div className="flex-1 h-px" style={{ background: "var(--infloro-divider)" }} />
    </div>
  );
}

function TrustBadges() {
  return (
    <div className="flex items-center justify-center gap-4 flex-wrap">
      {["SSL Secured", "GDPR Compliant", "Privacy Protected"].map(b => (
        <div key={b} className="flex items-center gap-1">
          <Shield size={10} style={{ color: "#4A7DFF" }} />
          <span style={{ fontSize: "11px", color: "var(--infloro-text-muted)" }}>{b}</span>
        </div>
      ))}
    </div>
  );
}

function RoleSwitcher({ role, onChange }: { role: "agency" | "creator"; onChange: (r: "agency" | "creator") => void }) {
  return (
    <div className="relative flex p-1 rounded-xl"
      style={{ background: "var(--infloro-input-bg)", border: "1px solid var(--infloro-border)" }}>
      <motion.div
        className="absolute top-1 bottom-1 rounded-lg"
        style={{
          background: GRAD,
          left: role === "agency" ? "4px" : "50%",
          right: role === "agency" ? "50%" : "4px",
        }}
        layoutId="rolePill"
        transition={{ type: "spring", stiffness: 420, damping: 32 }}
      />
      {(["agency", "creator"] as const).map(r => (
        <button key={r} onClick={() => onChange(r)}
          className="relative z-10 flex-1 py-2 text-sm font-semibold capitalize rounded-lg transition-colors duration-200"
          style={{ color: role === r ? "#fff" : "var(--infloro-text-secondary)" }}
        >
          {r === "agency" ? "Agency" : "Creator"}
        </button>
      ))}
    </div>
  );
}

// ─── Screen forms ──────────────────────────────────────────────────────────────

function LoginForm({ role, onNavigate }: { role: "agency" | "creator"; onNavigate: (s: Screen) => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  return (
    <motion.div key="loginform" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="flex flex-col gap-4">
      <SocialButtons />
      <Divider />
      <FloatingInput label="Email Address" type="email" icon={Mail} value={email} onChange={setEmail} autoComplete="email" />
      <FloatingInput label="Password" type="password" icon={Lock} value={password} onChange={setPassword} autoComplete="current-password" />
      <div className="flex justify-end">
        <button onClick={() => onNavigate("forgotPassword")} className="text-xs font-medium hover:underline" style={{ color: "#4A7DFF" }}>
          Forgot password?
        </button>
      </div>
      <GradientButton>Sign In <ArrowRight size={13} /></GradientButton>
      <p className="text-center text-xs" style={{ color: "var(--infloro-text-muted)" }}>
        Don't have an account?{" "}
        <button onClick={() => onNavigate(role === "agency" ? "agencySignup" : "creatorSignup")} style={{ color: "#4A7DFF" }} className="font-medium hover:underline">
          Sign up free
        </button>
      </p>
    </motion.div>
  );
}

function StepProgress({ step, total }: { step: number; total: number }) {
  return (
    <div className="flex gap-1.5">
      {Array.from({ length: total }, (_, i) => (
        <div key={i} className="h-1 flex-1 rounded-full transition-all duration-500"
          style={{ background: i <= step ? GRAD : "var(--infloro-border)" }} />
      ))}
    </div>
  );
}

function AgencySignup({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({ company: "", email: "", contact: "", phone: "", website: "", password: "" });
  const steps = [
    { title: "Company Info", fields: [{ key: "company", label: "Company Name", icon: Building2 }, { key: "email", label: "Company Email", icon: Mail, type: "email" }] },
    { title: "Contact Details", fields: [{ key: "contact", label: "Contact Person", icon: User }, { key: "phone", label: "Phone Number", icon: Phone }] },
    { title: "Final Setup", fields: [{ key: "website", label: "Website URL", icon: Globe }, { key: "password", label: "Password", icon: Lock, type: "password" }] },
  ];
  const current = steps[step];
  return (
    <motion.div key="agencysignup" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="flex flex-col gap-4">
      <StepProgress step={step} total={steps.length} />
      <div style={{ fontSize: "11px", fontWeight: 500, color: "var(--infloro-text-muted)" }}>Step {step + 1} of {steps.length} · {current.title}</div>
      <AnimatePresence mode="wait">
        <motion.div key={step} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} className="flex flex-col gap-3">
          {current.fields.map(f => (
            <FloatingInput key={f.key} label={f.label} icon={f.icon} type={(f as any).type || "text"}
              value={(form as any)[f.key]} onChange={v => setForm(p => ({ ...p, [f.key]: v }))} />
          ))}
        </motion.div>
      </AnimatePresence>
      <div className="flex gap-2">
        {step > 0 && (
          <button onClick={() => setStep(s => s - 1)}
            className="flex-1 py-3 rounded-xl text-sm font-medium transition-all hover:scale-[1.01]"
            style={{ border: "1px solid var(--infloro-border)", color: "var(--infloro-text-secondary)" }}>
            <ArrowLeft size={13} className="inline mr-1" /> Back
          </button>
        )}
        <GradientButton onClick={() => step < steps.length - 1 ? setStep(s => s + 1) : onNavigate("emailVerification")}>
          {step === steps.length - 1 ? "Create Account" : "Next"} <ArrowRight size={13} />
        </GradientButton>
      </div>
      <p className="text-center text-xs" style={{ color: "var(--infloro-text-muted)" }}>
        Already have an account?{" "}
        <button onClick={() => onNavigate("login")} style={{ color: "#4A7DFF" }} className="font-medium hover:underline">Sign in</button>
      </p>
    </motion.div>
  );
}

function CreatorSignup({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "", instagram: "", youtube: "" });
  const steps = [
    { title: "Basic Info", fields: [{ key: "name", label: "Full Name", icon: User }, { key: "email", label: "Email Address", icon: Mail, type: "email" }] },
    { title: "Account Setup", fields: [{ key: "phone", label: "Phone Number", icon: Phone }, { key: "password", label: "Password", icon: Lock, type: "password" }] },
    { title: "Creator Profile", fields: [{ key: "instagram", label: "Instagram Handle", icon: Instagram }, { key: "youtube", label: "YouTube Channel", icon: Youtube }] },
  ];
  const current = steps[step];
  return (
    <motion.div key="creatorsignup" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="flex flex-col gap-4">
      <StepProgress step={step} total={steps.length} />
      <div style={{ fontSize: "11px", fontWeight: 500, color: "var(--infloro-text-muted)" }}>Step {step + 1} of {steps.length} · {current.title}</div>
      {step === 0 && (
        <div className="grid grid-cols-2 gap-1.5">
          {["Manage brand deals", "Track collaborations", "Grow your business", "Secure workflows"].map(b => (
            <div key={b} className="flex items-center gap-1.5">
              <CheckCircle size={11} style={{ color: "#4A7DFF" }} />
              <span style={{ fontSize: "11px", color: "var(--infloro-text-secondary)" }}>{b}</span>
            </div>
          ))}
        </div>
      )}
      <AnimatePresence mode="wait">
        <motion.div key={step} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} className="flex flex-col gap-3">
          {current.fields.map(f => (
            <FloatingInput key={f.key} label={f.label} icon={f.icon} type={(f as any).type || "text"}
              value={(form as any)[f.key]} onChange={v => setForm(p => ({ ...p, [f.key]: v }))} />
          ))}
        </motion.div>
      </AnimatePresence>
      <div className="flex gap-2">
        {step > 0 && (
          <button onClick={() => setStep(s => s - 1)}
            className="flex-1 py-3 rounded-xl text-sm font-medium transition-all"
            style={{ border: "1px solid var(--infloro-border)", color: "var(--infloro-text-secondary)" }}>
            <ArrowLeft size={13} className="inline mr-1" /> Back
          </button>
        )}
        <GradientButton onClick={() => step < steps.length - 1 ? setStep(s => s + 1) : onNavigate("emailVerification")}>
          {step === steps.length - 1 ? "Join as Creator" : "Next"} <ArrowRight size={13} />
        </GradientButton>
      </div>
      {step === steps.length - 1 && (
        <button onClick={() => onNavigate("emailVerification")} className="text-center text-xs" style={{ color: "var(--infloro-text-muted)" }}>
          Skip for now
        </button>
      )}
      <p className="text-center text-xs" style={{ color: "var(--infloro-text-muted)" }}>
        Already have an account?{" "}
        <button onClick={() => onNavigate("login")} style={{ color: "#4A7DFF" }} className="font-medium hover:underline">Sign in</button>
      </p>
    </motion.div>
  );
}

function ForgotPassword({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [email, setEmail] = useState("");
  return (
    <motion.div key="forgot" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="flex flex-col gap-4">
      <p className="text-sm" style={{ color: "var(--infloro-text-secondary)" }}>Enter your email and we'll send you a reset link.</p>
      <FloatingInput label="Email Address" type="email" icon={Mail} value={email} onChange={setEmail} />
      <GradientButton onClick={() => onNavigate("emailVerification")}>Send Reset Link <ArrowRight size={13} /></GradientButton>
      <button onClick={() => onNavigate("login")} className="text-center text-xs flex items-center justify-center gap-1" style={{ color: "var(--infloro-text-muted)" }}>
        <ArrowLeft size={11} /> Back to Sign In
      </button>
    </motion.div>
  );
}

function EmailVerification({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const r0 = useRef<HTMLInputElement>(null);
  const r1 = useRef<HTMLInputElement>(null);
  const r2 = useRef<HTMLInputElement>(null);
  const r3 = useRef<HTMLInputElement>(null);
  const r4 = useRef<HTMLInputElement>(null);
  const r5 = useRef<HTMLInputElement>(null);
  const refs = [r0, r1, r2, r3, r4, r5];

  const handleOtp = (i: number, v: string) => {
    if (v.length > 1) return;
    const next = [...otp]; next[i] = v; setOtp(next);
    if (v && i < 5) refs[i + 1].current?.focus();
  };

  return (
    <motion.div key="verify" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="flex flex-col gap-4">
      <p className="text-sm" style={{ color: "var(--infloro-text-secondary)" }}>We sent a 6-digit code to your email. Enter it below to verify.</p>
      <div className="flex gap-2 justify-center">
        {otp.map((d, i) => (
          <input key={i} ref={refs[i]} maxLength={1} value={d}
            onChange={e => handleOtp(i, e.target.value)}
            onKeyDown={e => { if (e.key === "Backspace" && !d && i > 0) refs[i - 1].current?.focus(); }}
            className="w-10 h-12 text-center font-semibold outline-none rounded-xl transition-all"
            style={{
              background: "var(--infloro-input-bg)",
              border: `1px solid ${d ? "#4A7DFF" : "var(--infloro-input-border)"}`,
              boxShadow: d ? "0 0 0 3px rgba(74,125,255,0.15)" : "none",
              color: "var(--infloro-text-primary)",
              fontSize: "18px",
            }}
          />
        ))}
      </div>
      <GradientButton onClick={() => onNavigate("resetPassword")}>Verify Email <ArrowRight size={13} /></GradientButton>
      <p className="text-center text-xs" style={{ color: "var(--infloro-text-muted)" }}>
        Didn't receive it?{" "}
        <button style={{ color: "#4A7DFF" }} className="font-medium hover:underline">Resend code</button>
      </p>
      <button onClick={() => onNavigate("login")} className="text-center text-xs flex items-center justify-center gap-1" style={{ color: "var(--infloro-text-muted)" }}>
        <ArrowLeft size={11} /> Back to Sign In
      </button>
    </motion.div>
  );
}

function ResetPassword({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const strength = password.length > 11 ? 3 : password.length > 7 ? 2 : password.length > 3 ? 1 : 0;
  const strengthColors = ["#FF2D78", "#F59E0B", "#4A7DFF", "#22c55e"];
  return (
    <motion.div key="reset" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="flex flex-col gap-4">
      <p className="text-sm" style={{ color: "var(--infloro-text-secondary)" }}>Choose a strong password for your account.</p>
      <FloatingInput label="New Password" type="password" icon={Lock} value={password} onChange={setPassword} />
      {password && (
        <div className="flex gap-1">
          {[0, 1, 2, 3].map(i => (
            <div key={i} className="h-1 flex-1 rounded-full transition-all duration-300"
              style={{ background: i <= strength ? strengthColors[strength] : "var(--infloro-border)" }} />
          ))}
        </div>
      )}
      <FloatingInput label="Confirm Password" type="password" icon={Lock} value={confirm} onChange={setConfirm} />
      <GradientButton onClick={() => onNavigate("resetSuccess")}>Reset Password <ArrowRight size={13} /></GradientButton>
    </motion.div>
  );
}

function ResetSuccess({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  return (
    <motion.div key="success" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center gap-5 text-center py-4">
      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", delay: 0.2 }}
        className="w-16 h-16 rounded-full flex items-center justify-center"
        style={{ background: "linear-gradient(135deg, rgba(74,125,255,0.15), rgba(34,197,94,0.15))", border: "2px solid rgba(34,197,94,0.35)" }}>
        <CheckCircle size={28} style={{ color: "#22c55e" }} />
      </motion.div>
      <div>
        <div style={{ color: "var(--infloro-text-primary)", fontSize: "18px", fontWeight: 700 }}>Password Reset!</div>
        <p className="text-sm mt-1.5" style={{ color: "var(--infloro-text-secondary)" }}>
          Your password has been updated. You can now sign in with your new password.
        </p>
      </div>
      <GradientButton onClick={() => onNavigate("login")}>Back to Sign In <ArrowRight size={13} /></GradientButton>
    </motion.div>
  );
}

// ─── Screen config ──────────────────────────────────────────────────────────────

const screenConfig: Record<Screen, { title: string; subtitle: string }> = {
  login:             { title: "Welcome back",           subtitle: "Sign in to your Infloro account" },
  creatorLogin:      { title: "Creator Login",           subtitle: "Access your creator dashboard" },
  agencySignup:      { title: "Create Agency Account",   subtitle: "Start connecting with top creators" },
  creatorSignup:     { title: "Join as Creator",         subtitle: "Monetize your influence today" },
  forgotPassword:    { title: "Reset Password",          subtitle: "We'll help you get back in" },
  emailVerification: { title: "Check your email",        subtitle: "We sent you a verification code" },
  resetPassword:     { title: "New Password",            subtitle: "Create a secure new password" },
  resetSuccess:      { title: "All done!",               subtitle: "Your account is secured" },
};

// ─── Main export ──────────────────────────────────────────────────────────────

interface AuthCardProps {
  screen: Screen;
  onNavigate: (s: Screen) => void;
  role: "agency" | "creator";
  onRoleChange: (r: "agency" | "creator") => void;
}

export function AuthCard({ screen, onNavigate, role, onRoleChange }: AuthCardProps) {
  const isLogin = screen === "login" || screen === "creatorLogin";
  const isSignup = screen === "agencySignup" || screen === "creatorSignup";
  const cfg = screenConfig[screen];

  return (
    <div className="flex flex-col gap-5" style={{ fontFamily: "Inter, sans-serif" }}>
      <div>
        <div style={{ ...gradientText, fontSize: "22px", fontWeight: 700, lineHeight: 1.3 }}>{cfg.title}</div>
        <p className="text-sm mt-1" style={{ color: "var(--infloro-text-secondary)" }}>{cfg.subtitle}</p>
      </div>

      {(isLogin || isSignup) && (
        <RoleSwitcher role={role} onChange={r => {
          onRoleChange(r);
          if (isLogin) onNavigate("login");
          else onNavigate(r === "agency" ? "agencySignup" : "creatorSignup");
        }} />
      )}

      <AnimatePresence mode="wait">
        {isLogin && <LoginForm key="login" role={role} onNavigate={onNavigate} />}
        {screen === "agencySignup" && <AgencySignup key="agencysignup" onNavigate={onNavigate} />}
        {screen === "creatorSignup" && <CreatorSignup key="creatorsignup" onNavigate={onNavigate} />}
        {screen === "forgotPassword" && <ForgotPassword key="forgot" onNavigate={onNavigate} />}
        {screen === "emailVerification" && <EmailVerification key="verify" onNavigate={onNavigate} />}
        {screen === "resetPassword" && <ResetPassword key="reset" onNavigate={onNavigate} />}
        {screen === "resetSuccess" && <ResetSuccess key="success" onNavigate={onNavigate} />}
      </AnimatePresence>

      <TrustBadges />
    </div>
  );
}
