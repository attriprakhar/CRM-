
  # Design According to Prompt

  This is a code bundle for Design According to Prompt. The original project is available at https://www.figma.com/design/0oRdQFAKMx5swrIY9UuT2S/Design-According-to-Prompt.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  